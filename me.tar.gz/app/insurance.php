<?php
include 'db.php';
if(isset($_POST['submit'])){
$iname=$_POST['iname'];
$service=$_POST['service'];
	$xdate=$_POST['xdate'];
	$size=$_POST['csize'];
	$t="insert into insurance(inname,serv,cdate,csize) values('$iname','$service','$xdate','$size')";
	$tom=mysqli_query($con,$t);
	
	
}
if(isset($_POST['submit1'])){
	$iname=$_POST['iname'];
	
$sql=mysqli_query($con,"delete from insurance where inname='$iname'");
}
	
	
?>
<html><head>
<style>
#left{
float:left;

	width:30%;
	
}
#right{
float:right;

	width:70%;
}
	table,td,th{
	border:1px solid blue;
		width:90%;
		color:red;
		border-radius:5px;
		margin:2 auto;
		background-color:yellow;
	}
	body{
	color:red;
	background-color:purple;	
	}
	h1{
	text-align:center;
	}
</style>
</head>
<body>
<div id="left"><form method="post" action>
	<h1>ADD INSURANCE COMPANY</h1>
	<table>
	<tr><td>Insureance Name</td><td><input type="text" name="iname" /></td></tr>
	<tr><td>service</td><td><input type="text" name="service" /></td></tr>
	<tr><td>Date</td><td><input type="text" name="xdate" /></td></tr>
	<tr><td>car size</td><td><input type="text" name="csize" /></td></tr>
	<tr><td><input type="submit" name="submit" value="submit" /></td></tr>
			<tr><td><input type="submit" name="submit1" value="delete" /></td></tr>
			<tr><td><input type="submit" name="submit2" value="update" /></td></tr>
			
		
	</table>
	
	</form></div>
<div id="right">
	<h1>INSURANCE COMPANIES AVAILABLE</h1>
	<table>
		<tr>
		<td><input type="text" name="tom"/><input type="submit" name="submit3" value="search" /></td></tr>
		
	<tr>
		<th>Insurance company</th>
			<th>Service</th>
			<th>Date</th>
			<th>Car Size</th>
	</tr>
	<?php
	$w="select * from insurance";
	$results=mysqli_query($con,$w);
	
	if(mysqli_num_rows($results)>0){
		while($row=mysqli_fetch_array($results)){
		?>
	<tr>
		<td><?php echo $row["inname"];?></td>
		<td><?php echo $row["serv"];?></td>
		<td><?php echo $row["cdate"];?></td>
		<td><?php echo $row["csize"];?></td>
		<?php
		}
		}
		
		?>
	
		</table>
	</div>
	<div>Searched Work
	
		
		
	
	
	</div>
</body>

</html>
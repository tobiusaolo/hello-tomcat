<html>
<head>
	<style>
	#list li {
display: inline;
margin: 10px;
text-align: center;
		margin:0 auto;
   }

#list a {
text-decoration: none;
color: white;
}

#list {
background-color: blue;
width:  300px;
height: 25px;
border-radius: 5px;
}
		table{
		color:red;
		}
		

		.me{
		background-color:white;
		background-image:url('images/221308.jpg');	
			background-repeat:no-repeat;
			height:500px;
		}
		.go{
		background-color:black;
		}
		form{
		text-align:center;
			
		}
		input {
		margin-top:200px;
		}
		body{
		background-color:purple;
			color:red;
		}
	</style>
	</head>
<body>

<div id="list">

<ul>

<li> <a href="#"> Menu1 </a></li>

<li> <a href="#"> Menu2 </a></li>

<li> <a href="#"> Menu3 </a></li> 

</ul>

</div>
	<h1>Find car you need</h1>
	<p>A great car shopping experience usually involves a greate car dealership.Find dealers who specialize i new ,certified and used cars or trucks.</p>
<div class="me">
	<form method="post" action="find.php">
		<input type="text"/><input type="button" value="search car" name="submit"/>
		</form>
	
	</div>
	<h3>car dealers</h3>
	<div class="go">
	<table>
		<tr><th><img src="images/AppStore.png"/></th>
		<th><img src="images/GooglePlay.png"/></th></tr>
		
		<tr>
		<td rowspan='4'><h3>About us</h3><br/><br />
			<p>Car for Sale</p>
			<p>car Details</p>
			<p>Car Dealesr</p>
			</td>
			<td rowspan '4'><h3>Research</h3>
			<br/><br />
			<p>Car for Sale</p>
			<p>car Details</p>
			<p>Car Dealesr</p></td>
			
			<td rowspan='4' ><h3>Home</h3>
			<br/><br />
			<p>Car for Sale</p>
			<p>car Details</p>
			<p>Car Dealesr</p></td>
		
		</tr>
		</table>
	
	</div>

</body>

</html>
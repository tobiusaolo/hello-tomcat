<html>
<head>
	<style>
	#list li {
display: inline;
margin: 10px;
text-align: center;
		margin:0 auto;
   }

#list a {
text-decoration: none;
color: white;
}
		body{
		background-color:purple;
			color:red;
		}
#list {
background-color: blue;
width:  300px;
height: 25px;
border-radius: 5px;
}
		.right{
		float:right;
		}
		.left{
		float:left;
			margin-top:330px;
		}
		buttom{
		color:red;
		}
		
		.top,.wow{
			margin-top:20px;
		height:250px;
			width:500px;
			background-color:silver;
			text-align:center;
			border-radius:5px;
		}
		.me{
		background-color:lightgreen;
		background-image:url('images/landing-top.png');	
			background-repeat:no-repeat;
			height:500px;
			background-size:350px;
		}
		.go{
		background-color:black;
		}
		metoo{
		margin:0 auto;
		}
		
		
		
	</style>
	</head>
<body>

<div id="list">

<ul>

<li> <a href="#"> Menu1 </a></li>

<li> <a href="#"> Menu2 </a></li>

<li> <a href="#"> Menu3 </a></li> 

</ul>

</div>
	
<div class="me">
	<div class="left">
	<h3>How it works!</h3>
		<p>1. Tell us about your car and get your Instant Cash offer</p>
		<p>2.Visit a Partcipating Dealer to verify your car's features and condition. </p>
		<p>3.Use your offer to trade in your car or let the dealer buy it for cash.</p>
	
	
	</div>
<div class="right">
	<form method="post" action="find.php" class="top">
	<h3>Start with your Plate</h3>
		<input type="text"/><br /><br /><input type="button" value="Go" name="submit"/>
	<p>Entering this information will automatically fill in most of your vechicle information below and help<br />
	ensure your offer is more accurrate.This info will only be used to look up your VIN and will not be <br />stored.</p>
	
	
		</form>
	<form method="post" action="find.php" class="wow">
		<h3>Enter Vehicle Infromation</h3>
		<p>All fields are required</p>
		<table class="metoo">
		<tr><td><input type="text"/></td></tr>

		<tr><td><input type="text"/></td></tr>
		
		<tr><td><input type="text"/></td></tr>
		<tr><td><input type="text"/></td></tr>
		<tr><td><input type="text"/></td></tr>
		<tr><td><input type="button" value="Continue" name="submit"/></td></tr>
			
		</table>
		</form>
	
	</div>
	</div>
	<h3>car dealers</h3>
	<div class="go">
	<table class="buttom">
		<tr><th><img src="images/AppStore.png"/></th>
		<th><img src="images/GooglePlay.png"/></th></tr>
		
		<tr>
		<td rowspan='4'><h3>About us</h3><br/><br />
			<p>Car for Sale</p>
			<p>car Details</p>
			<p>Car Dealesr</p>
			</td>
			<td rowspan '4'><h3>Research</h3>
			<br/><br />
			<p>Car for Sale</p>
			<p>car Details</p>
			<p>Car Dealesr</p></td>
			
			<td rowspan='4' ><h3>Home</h3>
			<br/><br />
			<p>Car for Sale</p>
			<p>car Details</p>
			<p>Car Dealesr</p></td>
		
		</tr>
		</table>
	
	</div>

</body>

</html>
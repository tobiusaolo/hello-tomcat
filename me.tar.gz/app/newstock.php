<?php
if(isset($_POST['submit'])){
$sub=$_POST['sub'];
	$sender=$_POST['me'];
	$order=$_POST['order'];
	$email=$_POST['to'];
	if(mail($sub,$sender,$order,$email)){
	echo "email successfully sent";
	}else{
	echo "Email delivery failed!! ";
	}
}

?>
<html>
<head><style>
	table{
	border:2px solid blue;
		margin:0 auto;
		background-color:yellow;
		width:60%;
		height:500px;
	}
	td{
	
		text-align:center;
	}
	textarea{
	width:80%;
		height:200px;
	}
	#suj{
	width:80%;
	}
	body{
	background-color:purple;
		color:red;
	}
	</style></head>
<body>
<form method="post" action="newstock.php">
<table>
<tr><th><h1>Send order</h1></th></tr>
<tr><td>Subject:</td><td><input type="text" id="suj" name="sub"/></td></tr>
<tr><td>From:</td><td><input type="text" id="suj" name="me"/></td></tr>
<tr><td>Write Order</td></tr>
<tr><td colspan="4"><textarea name="order"></textarea></td></tr>
<tr><td>Email:</td><td><input type="email" id="suj" name="to"/></td></tr>
<tr><td><input type="submit" name="submit" value="send order" /></td></tr>
</table>

</form>


</body>


</html>
<?php
include 'db.php';
$r="select * from cars";
$result=mysqli_query($con,$r);
?>
<html><head><style>
	table,th,td{
	border:1px solid blue;
		margin:0 auto;
	}
	</style><head><body>
<table>
<tr>
<th>Car Name</th>
	<th>Car Model</th>
	<th>Car size</th>
	<th>Stake</th>
	<th>Customer</th>
	<th>Date of order</th>

</tr>
	<?php
	if(mysqli_num_rows($result)>0){
	while($row=mysqli_fetch_array($result)){
	?>
	<tr>
		<td><?php echo $row["cname"];?></td>
		<td><?php echo $row["cmodel"];?></td>
		<td><?php echo $row["csize"];?></td>
		<td><?php echo $row["cstake"];?></td>
		<td><?php echo $row["ccname"];?></td>
		<td><?php echo $row["cdate"];?></td>
		
		</tr>
	<?php
	}
	
	}
	
	?>

</table>

</body></html>
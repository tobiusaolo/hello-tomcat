<html>
<head></head>
<body>
<table>
	<tr>
		<th>Employee Name</th>
		<th>GENDER</th>
		<th>Allowances</th>
		<th>POSTION</th>
		<th>TIME WORKED</th>
	</tr>
	
	</table>


</body>


</html>
<?php
include 'db.php';
if(isset($_POST['submit'])){
$car=$_POST['type'];
	$sold=$_POST['sold'];
	$customer=$_POST['cname'];
	$date=$_POST['date'];
	$sales=$_POST['sales'];
	$sw="insert into transcations(cartype,amountSold,cname,cdate,salesman) values('$car','$sold','$customer','$date','$sales')";
	$med=mysqli_query($con,$sw);

}


?>

<html>
<head>
	<script>
	
	</script>
	<style>
		table{
		background-color:yellow;
		margin: 0 auto;
		}
		#left{
		float:left;
			width:30%;
		}
		#right{
		float:right;
			width:70%;
		}
		.table1{
		width:80%;
		}
		.table2{
		width:80%;
			border:1px solid blue;
		}
		body{
		background-color:purple;
			color:red;
		}
	</style>
	</head>
<body>
<div id="left">
<form method="post" action="sales.php">
	<table class="table1">
<tr><td><label>Enter car type</label><br /><br /><input type="text" name="type" /></td><tr>
<tr><td><label>Amount sold</label><br /><br /><input type="text" name="sold" /></td><tr>
<tr><td><label>Customer Name</label><br /><br /><input type="text" name="cname"/></td><tr>
<tr><td><label>Date</label><br /><br /><input type="date" name="date"/></td><tr>
<tr><td><label>Salesman</label><br /><br /><input type="text" name="sales"/></td><tr>


<tr><td><label>Submit Transcation</label><br /><br /><input type="submit" value="submit" name="submit"/></td><tr>
	</table>
</form>
</div>
<div id="right">
<table class="table2">
	<tr>
	<th>Car Type</th>
	<th>Amount Sold</th>
	<th>Customer</th>
		<th>Date Sold</th>
	<th>Salesman</th>

	</tr>
	<?php
	$r=mysqli_query($con,"select * from transcations");
	
	if(mysqli_num_rows($r)>0){
	while($row=mysqli_fetch_array($r)){
		?>
	<tr>
		<td><?php echo $row['cartype'];?></td>
		<td><?php echo $row['amountSold'];?></td>
		<td><?php echo $row['cname'];?></td>
		<td><?php echo $row['cdate'];?></td>
		<td><?php echo $row['salesman'];?></td>
		</tr>
	<?php
	}
	}	
	?>
	</table>
</div>

</body>


</html>
<html>
<head><title>Stock page</title>
<link rel="stylesheet" type="text/css" href="stock.css"/>
	<link rel="stylesheet" type="text/css" href="menu.css"/>
	</head>
<body><div id="head"><h1>EXPRESS MOTORS</h1></div>
	<div id="head"><nav><!--start of the the navigation bar in the table column-->
			<ul>
				<li><a href="#">Home</a><!--main menu-->
			
					</li>
				<li><a href="#">Salesmen</a>
				</li>	
				<li><a href="form.html">Insurence</a></li>
				<li><a href="#">View Reciept</a></li>
				<li><a href="#">Other services</a></li>
				<li><a href="#">Order</li>
				<li><a href="#">Help</a></li>
			</ul><!-- end of main menu list-->
		</nav></div>
<section id="left">
	<button class="sale">View salesmen</button><br/>
	<button class="order">Make order</button><br/>
	<button class="make">Make Appoitment</button><br/>
	<button class="term">View Terms </button><br/>
	<button class="isu">View Insurence</button><br/>
	<button class="stock">Pending Stock</button><br/>
	<h1>About us</h1>
	<button class="awrd">Awards</button><br/>
	<button class="co">Consultacny</button><br/>
	<button class="ware">View WareHouse</button><br/>
	<button class="ass">Associates</button><br/>
	</section>
<aside id="center"><table border="1px">
	<tr>
		<td><img src="images/1.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
		<td><img src="images/2.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
		<td><img src="images/3.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
		</tr>
		<tr>
			<td><img src="images/4.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
			<td><img src="images/5.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
			<td><img src="images/6.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
	</tr>
		<tr>
			<td><img src="images/7.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
			<td><img src="images/8.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
			<td><img src="images/9.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
	</tr>
		<tr>
			<td><img src="images/10.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
			<td><img src="images/11.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
			<td><img src="images/15.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
	</tr>
		<tr>
			<td><img src="images/13.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
			<td><img src="images/22.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
			<td><img src="images/19.jpg"/><br/>
			<lable><img src="images/boo2.png" height="30px" width="30px"/>MercedezBenz:$1200<br/>
				Model:2017</label></td>
	</tr>
	
	<tr>
	<td>
	<button class="face"><img src="images/26.png"height="40px" width="40px"/></button>
		</td><td>
	<button class="Twitter"><img src="images/28.png" height="40px" width="40px"/></button>
		</td><td>
	
<button class="whatapp"><img src="images/29.png" height="40px" width="40px"/> </button>
	
		</td>
	</tr>
	</table>
	
	</aside>

</body>

</html>
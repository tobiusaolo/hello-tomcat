<?php
include 'db.php';


$w="select * from employees where position='$pos'";
$res=mysqli_query($con,$w);


?>
<html>
<head><title></title>
	<style>
		table{
		border:1px solid blue;
			margin:0 auto;
			width:80%;
			background-color:yellow;
			border-radius:5px;
		}
		tr:nth-child(even) {background-color: #f2f2f2;}
		td{
			
			border-bottom: 1px solid #ddd;
		text-align:center;
			padding:15px;
			height:50px;
			vertical-align:bottom;
		}
		body{
		background-color:purple;
		}
		h1{
		color:red;
			text-align:center;
		}
		div{
		float:right;
		}
		th {
    background-color: #4CAF50;
    color: white;
			  border-bottom: 1px solid #ddd;
			padding: 15px;
    text-align: left;
}
	</style>
	</head>
<body>
	<h1>Staff Members</h1>
	<div><input type="text" /><input type="submit" value="search" name="submit1"/></div>
<table>
	<tr><th>EMPLOYEE NAME</th>
	<th>POSITION</th>
	<th>GENDER</th>
	<th>AGE</th>
	<th>SALARY</th></tr>
	<?php
	if(mysqli_num_rows($res)>0){
	while($row=mysqli_fetch_array($res)){
	
	?>
	<tr>
		<td><?php echo $row["name"];?></td>
		<td><?php echo $row["position"];?></td>
		<td><?php echo $row["age"];?></td>
		<td><?php echo $row["gender"];?></td>
		<td><?php echo $row["salary"];?></td>
	
	</tr>
	<?php
	}
	
	}
	
	?>
	</table>	
	
	
	</body>
</html>
<?php
include 'db.php';
?>
<html>
<head>
<meta name="description" content="Php Code for View, Search, Edit and Delete
Record" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Search Employee Record</title>
</head>
<body  style="background-color:silver;">
<center><h1><u>Supermarket Database</u></h1></center>
<form name="search" method="post" action="emplist.php" width="1200px" >
<table style=" border:1px solid #0066FF" cellpadding="5px" width="75%" cellspacing="0px"
align="center" border="0" height="400px">
<tr>
<td colspan="3" style="background:#0066FF; color:#FFFFFF; fontsize:
20px">Search</td></tr>
<tr>
<td style="color: white;">Enter Search Keyword</td>
<td><input type="text" name="search" size="50" placeholder="Enter employee name here....." /></td>
<td><input type="submit" value="Search" /></td>
</tr>
<tr bgcolor="#666666" style="color:#FFFFFF">
<td>EmpID </td>
<td style="color: white;">Name & Email</td>
<td style="color: white;">&nbsp;</td>
<?php
	
$search=$_POST["search"];
$flag=0;c
$query="SELECT * FROM employees WHERE name || position LIKE '%$search%' ";
$result=mysql_query($query);
while ($row = mysql_fetch_array($result)) {
$flag=1;
echo "<tr ><td>",$row[0],"</td><td><a
href='view.php?Employee_id=",$row[0],"'>",$row[2],", ",$row[4],"</a></td><td><a
href='edit.php?Employee_id=",$row[0],"'>Edit</a> | <a
href='del.php?Employee_id=",$row[0],"'>Delete</a></td></tr>";
}
if($flag==0)
echo "<tr><td colspan='3' align='center' style='color:red'>Record not
found</td></tr>";
?>
<tr>
<td colspan="3">&nbsp;</td></tr>
<tr bgcolor="#0066FF">
<th colspan="3" align="right"><a href="add.php">Add Record</a></th>
</tr>
</table>
</form>
</body>
</html>
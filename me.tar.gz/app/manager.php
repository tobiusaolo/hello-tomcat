<html>
<head><title></title>
	<link rel="stylesheet" type="text/css" href="menu.css"/>
	<link rel="stylesheet" type="text/css" href="manager.css"/>
	
	</head>
<body>
	<div id="head"><nav><!--start of the the navigation bar in the table column-->
			<ul>
				<li><a href="#">Home<img src="down.png"/></a><!--main menu-->
			
					</li>
				<li><a href="#">Salesmen<img src="down.png"/></a>
				</li>	
				<li><a href="form.html">Insurence<img src="down.png"/></a></li>
				<li><a href="#">View Reciepts<img src="down.png"/></a></li>
				<li><a href="#">Other services<img src="down.png"/></a></li>
				<li><a href="#">Order</a></li>
				<li><a href="#">Help</a></li>
			</ul><!-- end of main menu list-->
		</nav></div>
<form>
<h1>Manager Information</h1>
	<table>
	<tr>
	<td><input type="button" class="emp"  value="View Employee list" onClick="parent.location='emplist.php'"/></td>	
		<td><input type="button" class="add" onClick="parent.location='add.php'" value="Add Employee"/></td>	
		
		</tr>
	<tr>
	<td><input type="button" class="stock" value="View Stock" onclick="parent.location=''"/></td>	
		<td><input type="button" class="orders" value="View Customer Orders" onClick="parent.location='viewstock.php'"/></td>	
		
		</tr>
		<tr>
	<td><input type="button" class="pass" value="Check finacial Status" onclick="parent.location=''" /></td>	
		<td><input type="button" class="view" value="View Employee Allowances" onclick="parent.location='allowances.php'"/></td>	
		
		</tr>
	<tr>
	<td><input type="button" class="Trans" value="Complete Transactions" onclick="parent.location='sales.php'"/></td>	
		<td><input type="button" class="order" value="Order new Stock" onclick="parent.location='newstock.php'"/></td>	
		
		</tr>
	<tr>
	<td><input type="button" class="view" value="View Customer comments" onclick="parent.location=''"/></td>	
		<td><input type="button" class="issu" value="Insurence Groups" onclick="parent.location='insurance.php'"/></td>	
		
		</tr>
	
	</table>
	
	
	
</body>



</html>
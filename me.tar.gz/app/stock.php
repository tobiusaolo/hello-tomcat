-<?php
$msg="";
if(isset($_POST['upload'])){
	$target="images/".basename($_FILES['image']['name']);
	include 'db.php';

	$image=$_FILES['image']['name'];
	$text=$_POST['text'];

	$sql="insert into image(image,text) values('$image','$text')";
	mysqli_query($con,$sql);

	if(move_uploaded_file($_FILES['image']['tmp_name'], $target)){
		$msg="image uploaded successfully";

	}else{
		$msg="image not uploaded";
	}
}


?>

<html>
<head></head>
<body>
<div id="content">
<?php
include "db.php";
$sql="select * from image";
$result=mysqli_query($con,$sql);
while($row=mysqli_fetch_array($result)){
	echo"<div id='img_div'>";
	echo"<img src='".$row['image']."'>";
	echo"<p>".$row['text']."</p>";
	echo "</div>";
}
?>
<form method="post" action="stock.php" enctype="multipart/form-data">
<input type="hidden" name="size" value="1000000">
<div>
	<input type="file" name="image">
</div>	
<div>
	<textarea name="text" cols="40" rows="4" placeholder="text here">
		
	</textarea>
</div>
<div>
	<input type="submit" name="upload" value="upload image">
</div>
</form>
</div>
</body>
</html>
<html>
<head></head>
<body>
<form>
<h5>Search Cars for sale</h5>
<table>
<tr>
<td><label><h4>Condition</h4></label></td>
<td><input type="checkbox"/><input type="checkbox"/><input type="checkbox"/><span>Learn more about certified pre-owned cars</span></td>
</tr>
<tr><td><label>Price</label><br /><br /></tr>
	<input type="price" placeholder="AnyPrice"/><input type="price" placeholder="Any price"/>
	</td></tr>
	<tr>
	<td>Style</td>
	</tr>
	<tr>
	<td><table>
		<tr><th>ALL styles</th></tr>
		<tr>
		<td>AWD/4WD</td>
			<td>Commercial</td>
			<td>Convertible</td>
		</tr>
		<tr>
		<td>Hatchback</td>
			<td>Hybrid/elctric</td>
			<td>Luxury</td>
		</tr>
		<tr>
		<td>SUV/Crossover</td>
			<td>Truck</td>
			<td>Van/Minivan</td>
		</tr>
		</table></td>
	</tr>
	
</table>

</form>
</body>

</html>
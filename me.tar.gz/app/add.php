<?php
include'db.php';
if(isset($_POST['submit'])){
$empname=$_POST['empname'];
	$pos=$_POST['pos'];
	$age=$_POST['age'];
	$gender=$_POST['gender'];
	$salary=$_POST['salary'];
	$d ="insert into employees(name,position,age,gender,salary) values('$empname','$pos','$age','$gender','$salary')";
$me=mysqli_query($con,$d);
}

?>

<html>
<head><title></title>
	<style>
		table{
	
			margin:0 auto;
			width:60%;
			height:500px;
		}
		td{
		text-align:center;
			background-color:yellow;
			color:red;
		}
		body{
		background-color:purple;
			color:red;
		}
		input{
		width:80%;
			height:60px;
		}
		h1{
		text-align:center;
		}
	</style>
	
	</head>
<body>
<form action="" method="post">
	<h1>ADD EMPLOYEE </h1>
<table>
<tr>
<td><label>Employee Name</label></td><td><input type="text" name="empname" /></td>

</tr>
<tr>
<td>Postion</td><td><input type="text" name="pos" /></td>

</tr>
<tr>
<td>age</td><td><input type="text" name="age" /></td>

</tr>
<tr>
<td>Gender</td><td><input type="text" name="gender" /></td>

</tr>
<tr>
<td>Salary</td><td><input type="text" name="salary" /></td>

</tr>
	<tr>
<td><input type="submit" name="submit" value="submit" /></td>

</tr>

</table>


</form>

</body>

</html>
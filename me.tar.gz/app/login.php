<?php
include 'db.php';
if(isset($_POST['submit'])){
$user=$_POST['user'];
	$pass=$_POST['pass'];
	if($user=='' || $pass==''){
	echo "all fields are required please";
	}
		else{
		$sql="select user,pass from members where user='$user' and pass='$pass'";
			if(mysqli_num_rows(mysqli_query($con,$sql))==0){
			echo "invalid username/password";
			}else{
			die("You are now logged in. Please <a href='home.php?view=$user'>" .
"click here</a> to continue.<br /><br />");
			}
		
	}
	
}

?>
<html>
<head></head><body>
	<form action="login.php" method="post">
		<table>
			<tr><th><button>Signup</button></th><th><button onclick='redirect()'>Login</button></th></tr>
		<tr><td>User</td><td><input type="text" name="user"/></td></tr>
			<tr><td>Password</td><td><input type="password" name="pass"/></td></tr>
			
			<tr><td>Login</td><td><input type="submit" name="submit" value="submit"/></td></tr>
			
			
		</table>
	</form>
	</body>

</html
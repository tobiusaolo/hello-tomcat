<html>
<head>
	<style>
	#list li {
display: inline;
margin: 10px;
text-align: center;
		margin:0 auto;
   }

#list a {
text-decoration: none;
color: white;
}

#list {
background-color: blue;
width:  300px;
height: 25px;
border-radius: 5px;
}
		table{
		color:red;
		}
		

		.me{
		background-color:white;
		
			height:500px;
		}
		.go{
		background-color:black;
		}
		body{
		background-color:purple;
			color:red;
		}
		
	</style>
	</head>
<body>

<div id="list">

<ul>

<li> <a href="#"> Menu1 </a></li>

<li> <a href="#"> Menu2 </a></li>

<li> <a href="#"> Menu3 </a></li> 

</ul>

</div>
	<h1>Get competitive rates on the Car<br />You Always Wanted!</h1>
	<p>Shop with the confidence of a cash buyer.Apply online<br />and get a decision in seconds!</p>
	<button>Apply today</button>
	
<div class="me">
	<table>
	<tr><td>Complete one simple form</td><td>Get a decision in seconds</td><td><p>Download your loan voucher and<br />shop like a cash buyer</p></td></tr>
	<tr><td><p>Competitive Rates</p>
		<p>Trusted lender with over 2 million customers</p>
		<p>Simple application,fast loan decisions</p>
		<p>All credit types accepted</p></td></tr>
	</table>
	
	</div>
	<h3>car dealers</h3>
	<div class="go">
	<table>
		<tr><th><img src="images/AppStore.png"/></th>
		<th><img src="images/GooglePlay.png"/></th></tr>
		
		<tr>
		<td rowspan='4'><h3>About us</h3><br/><br />
			<p>Car for Sale</p>
			<p>car Details</p>
			<p>Car Dealesr</p>
			</td>
			<td rowspan '4'><h3>Research</h3>
			<br/><br />
			<p>Car for Sale</p>
			<p>car Details</p>
			<p>Car Dealesr</p></td>
			
			<td rowspan='4' ><h3>Home</h3>
			<br/><br />
			<p>Car for Sale</p>
			<p>car Details</p>
			<p>Car Dealesr</p></td>
		
		</tr>
		</table>
	
	</div>

</body>

</html>
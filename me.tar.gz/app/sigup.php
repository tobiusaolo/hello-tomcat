<?
include 'db.php';
if(isset($_POST['submit'])){
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	$email=$_POST['email'];
	if($user=='' || $pass=='' || $email==''){
	echo"all fields are required";
	}else
	{
		$q=mysqli_query($con,"select * from members where user='$user'");
	if(mysqli_num_rows($q)){
		echo "username is already taken";
	}
		else{
		mysqli_query($con,"insert into members(user,pass,email)values ('$user','$pass','$email')");
			echo"account created";
		}
	}


}

?>
<html>
<head></head><body>
	<form action="sigup.php" method="post">
		<table>
			<tr><th><button>Signup</button></th><th><button onclick='redirect()'>Login</button></th></tr>
		<tr><td>User</td><td><input type="text" name="user"/></td></tr>
			<tr><td>Password</td><td><input type="password" name="pass"/></td></tr>
			<tr><td>Email</td><td><input type="email" name="email"/></td></tr>
			<tr><td>signup</td><td><input type="submit" name="submit" value="submit"/></td></tr>
			<a href="login.php">click here to login</a>
			
		</table>
	</form>
	</body>

</html>
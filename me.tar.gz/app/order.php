<?php
include'db.php';

if(isset($_POST['submit'])){
	$car =$_POST['car'];
	$model=$_POST['model'];
	$size=$_POST['size'];
	$stake=$_POST['stake'];
	$customer=$_POST['customer'];
	$date=$_POST['date'];
	
	$sq="insert into cars(cname,cmodel,csize,cstake,ccname,cdate) values('$car','$model','$size','$stake','$customer','$date')";
	$result=mysqli_query($con,$sq);
	
	
}
?>
<html>
	<head><title></title>
	<link rel="stylesheet" type="text/css" href="order.css"/>
	<link rel="stylesheet" type="text/css" href="menu.css"/></head>
	</head>
		<body>
			<div id="head"><nav><!--start of the the navigation bar in the table column-->
			<ul>
				<li><a href="#">Home<img src="down.png"/></a><!--main menu-->
			
					</li>
				<li><a href="#">Salesmen<img src="down.png"/></a>
				</li>	
				<li><a href="form.html">Insurence<img src="down.png"/></a></li>
				<li><a href="#">View Reciepts<img src="down.png"/></a></li>
				<li><a href="#">Other services<img src="down.png"/></a></li>
				<li><a href="#">Order</a></li>
				<li><a href="#">Help</a></li>
			</ul><!-- end of main menu list-->
		</nav></div>
			<form method="post" action="">
				<table>
					<tr><td>Car Name</td><td><input type="text" placeholder="input car name" name="car" /></td></tr>
					<tr><td>Enter Model</td><td><input type="text" name="model" placeholder="enter car model"/></td></tr>
					<tr><td>size</td><td><input type="text" name="size" placeholder="enter car model"/></td></tr>
					<tr><td>stake</td><td><input type="text" name="stake" placeholder="enter car model"/></td></tr>
					<tr><td>Customer Name</td><td><input type="text" name="customer" placeholder="enter car model"/></td></tr>
					<tr><td>Date</td><td><input type="text" name="date" placeholder="enter car model"/></td></tr>
					<tr><td><input type="submit" name="submit" value="submit"/></td></tr>
					
				</table>
				
			</form>
		</body>

</html>
